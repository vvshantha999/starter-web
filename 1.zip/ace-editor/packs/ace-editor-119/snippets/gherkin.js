ace.define("ace/snippets/gherkin",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "gherkin";

});
